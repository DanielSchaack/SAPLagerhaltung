sap.ui.define([
	"namespace/Supermarkt/test/unit/controller/Login.controller"
], function () {
	"use strict";
});