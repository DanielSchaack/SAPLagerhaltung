sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel"
], function (Controller, MessageBox, ODataModel) {
	"use strict";
	return Controller.extend("namespace.Supermarkt.controller.Produktaenderung", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf namespace.Supermarkt.view.Produktaenderung
		 */
		onInit: function () {

		},
		/**
		 *@memberOf namespace.Supermarkt.controller.Produktaenderung
		 */
		onAenderung: function (oEvent) {
			//Funktion zum Updaten der Daten in der Datenbank. Bekommt oEntry, welche alle Daten enthält, unter anderem die ProduktID, die genutzt wird, um beim Updaten das richtige Listenelement zu finden
			function updateLager(oEntry, oModel) {
				oModel.update("/Lager(" + oEntry.ProduktID + ")", oEntry, {
					merge: true,
					success: function (oData1, oResult1) {},
					error: function (oError) {}
				});
			}

			// Funktionen zum Leeren der Inputfelder mit/ohne zur Navigation zurück zur Übersicht.
			function resetInput(oCombo, oInput, oRouter) {
				oCombo.setSelectedKey("");
				oInput.setValue("");
				oRouter.navTo("Uebersicht");
			}

			function resetInputNoRout(oCombo, oInput) {
				oCombo.setSelectedKey("");
				oInput.setValue("");
			}

			//Hole Model und Router von der View
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			//Hole die Combobox, sowie der eingegebene Wert
			var oCombo = this.getView().byId("combo1");
			var PrName = oCombo.getValue();

			//hole den Wert der Selectbox
			var Aenderung = this.getView().byId("select0").getSelectedItem().getText();

			//hole die Inputbox sowie dessen Wert, konvertiere diesen Wert zu einem Int
			var oInput = this.getView().byId("input2");
			var Anzahl = oInput.getValue();
			var IntAnzahl = parseInt(Anzahl);

			//erstelle einen Filter, um den gegebenen Datensatz mit  dem eingegebenen Produktnamen zu vergleichen
			var filter = new sap.ui.model.Filter("PrName", sap.ui.model.FilterOperator.EQ, "" + PrName + "");

			//boolesche Variablen zum Überprüfen, dass die Inputfelder belegt wurden
			var istNameVorhanden = false;
			var istAnzahlVorhanden = false;

			//Deklarierung von oEntry, später genutzt zum Updaten der Datenbank
			var oEntry = {};

			//prüft, ob Zahl eingegeben wurde
			if (Anzahl.length !== 0) {
				istAnzahlVorhanden = true;
			}

			//Lese aus der Datenbank, ob ein Datensatz mit dem eingegebenen namen existiert
			oModel.read("/Lager", {
				filters: [filter],
				success: function (oData, oResult) {

					//wenn dieser Satz existiert, und nur dieser, dann bereite das Updaten vor
					if (oData.results.length === 1) {

						istNameVorhanden = true;

						//oEntry mit gegebenen Satz belegen
						oEntry.Adresse = oData.results[0].Adresse;
						oEntry.AnbName = oData.results[0].AnbName;
						oEntry.Ort = oData.results[0].Ort;
						oEntry.ProduktID = oData.results[0].ProduktID;
						oEntry.Schwellenwert = oData.results[0].Schwellenwert;
						oEntry.Preis = oData.results[0].Preis;
						oEntry.PrName = oData.results[0].PrName;
						oEntry.AnbieterID = oData.results[0].AnbieterID;

						//wenn alle Inputfelder belegt sind, dann den Bestand anschauen
						if (istAnzahlVorhanden && istNameVorhanden) {
							var bestand = oData.results[0].Bestand;

							if (Aenderung === "Reduzieren") {
								//wenn Bestand minus der Eingabe unterhalb 0, dann ist der neue Bestand 0, Datensatz updaten
								if (bestand - IntAnzahl < 0) {
									oEntry.Bestand = 0;
									updateLager(oEntry, oModel);
									resetInput(oCombo, oInput, oRouter);

									//ansonsten ist der neue Bestand der alte minus der Eingabe
								} else {
									oEntry.Bestand = bestand - IntAnzahl;
									updateLager(oEntry, oModel);
									resetInput(oCombo, oInput, oRouter);
								}

								//wenn die Änderung hinzufügen ist, dann ist der neue Bestand der alte mit der Eingabe addiert
							} else {
								oEntry.Bestand = bestand + IntAnzahl;
								updateLager(oEntry, oModel);
								resetInput(oCombo, oInput, oRouter);
							}
						}

						//wenn der Name nicht enthalten ist, dann geb eine Nachricht aus und resete die Inputfelder
					} else {
						MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "",
							actions: [sap.m.MessageBox.Action.OK]
						});
						resetInputNoRout(oCombo, oInput);
					}
				},
				error: function (oError) {}
			});
		}
	});
});