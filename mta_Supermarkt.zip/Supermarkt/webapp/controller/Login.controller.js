sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Sorter"
], function (Controller, MessageBox, ODataModel, Sorter) {
	"use strict";
	return Controller.extend("namespace.Supermarkt.controller.Login", {
		onInit: function () {},
		/**
		 *@memberOf namespace.Supermarkt.controller.Login
		 */

		/**
		 *@memberOf namespace.Supermarkt.controller.Login
		 */
		login: function (oEvent) {
			function resetInput(oInput, oInput1, oInput2) {
				oInput.setValue("");
				oInput1.setValue("");
				oInput2.setValue("");
			}
			//Hole Model und Router von der View
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			//hole die Inputbox sowie dessen Wert
			var oInput = this.getView().byId("input0");
			var Vorname = oInput.getValue();

			var oInput1 = this.getView().byId("input1");
			var Nachname = oInput1.getValue();

			var oInput2 = this.getView().byId("input2");
			var Passwort = oInput2.getValue();

			var filter1 = new sap.ui.model.Filter("Vorname", sap.ui.model.FilterOperator.EQ, "" + Vorname + "");
			var filter2 = new sap.ui.model.Filter("Nachname", sap.ui.model.FilterOperator.EQ, "" + Nachname + "");
			var filter3 = new sap.ui.model.Filter("Passwort", sap.ui.model.FilterOperator.EQ, "" + Passwort + "");

			oModel.read("/Mitarbeiter", {
				filters: [filter1, filter2, filter3],
				success: function (oData, oResult) {

					if (oData.results.length === 1) {
						resetInput(oInput, oInput1, oInput2);
						oRouter.navTo("Uebersicht");

					}else {
							MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: "",
								actions: [sap.m.MessageBox.Action.OK]
							});
							resetInput(oInput, oInput1, oInput2);
					}

				}
			});
		}
	});
});