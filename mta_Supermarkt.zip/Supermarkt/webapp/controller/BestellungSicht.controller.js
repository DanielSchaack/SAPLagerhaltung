sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/Sorter"
], function (Controller, MessageBox, ODataModel, Sorter) {
	"use strict";
	return Controller.extend("namespace.Supermarkt.controller.BestellungSicht", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf namespace.Supermarkt.view.BestellungSicht
		 */
		onInit: function () {},
		/**
		 *@memberOf namespace.Supermarkt.controller.BestellungSicht
		 */
		erstelleStandVorhanden: function (oEvent) {

			// Funktionen zum Leeren der Inputfelder mit/ohne zur Navigation zurück zur Übersicht.
			function resetInput(oCombo, oInput, oRouter) {
				oCombo.setSelectedKey("");
				oInput.setValue("");
				oRouter.navTo("Anbieterstand");
			}

			function resetInputNoRout(oCombo, oInput) {
				oCombo.setSelectedKey("");
				oInput.setValue("");
			}

			function createAnbieterstand(oEntry, oModel) {
				oModel.read("/Wegwerf(1)", {
					success: function (oData1, oResult1) {
						oModel.remove("/Wegwerf(1)", {});
						oModel.create("/Wegwerf", oEntry, {});
					},
					error: function (oError) {
						oModel.create("/Wegwerf", oEntry, {});
					}
				});
			}
			//Hole Model und Router von der View
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//Hole die Combobox, sowie der eingegebene Wert
			var oCombo = this.getView().byId("combo1");
			var PrName = oCombo.getValue();
			//hole die Inputbox sowie dessen Wert, konvertiere diesen Wert zu einem Int
			var oInput = this.getView().byId("input4");
			var Anzahl = oInput.getValue();
			var IntAnzahl = parseInt(Anzahl);
			//boolesche Variablen zum Überprüfen, dass die Inputfelder belegt wurden
			var istNameVorhanden = false;
			var istAnzahlVorhanden = false;

			//Deklarierung von oEntry, später genutzt zum Updaten der Datenbank
			var oEntry = {};
			//erstelle einen Filter, um den gegebenen Datensatz mit  dem eingegebenen Produktnamen zu vergleichen
			var filter = new sap.ui.model.Filter("ProName", sap.ui.model.FilterOperator.EQ, "" + PrName + "");
			//prüft, ob Zahl eingegeben wurde
			if (Anzahl.length !== 0) {
				istAnzahlVorhanden = true;
			}
			//Lese aus der Datenbank, ob ein Datensatz mit dem eingegebenen namen existiert
			oModel.read("/Produktliste", {
				filters: [filter],
				success: function (oData, oResult) {
					//wenn dieser Satz existiert, und nur dieser, dann bereite das Updaten vor
					if (oData.results.length === 1) {
						istNameVorhanden = true;
						//oEntry mit gegebenen Satz belegen
						oEntry.Aufzaehlung = 1;
						oEntry.Produktname = oData.results[0].ProName;
						oEntry.gefordert = IntAnzahl;
						oEntry.angeboten = oData.results[0].Bestand;
						var preis = parseFloat(oData.results[0].Preis) * IntAnzahl;
						oEntry.WPreis = preis.toString();
						//wenn alle Inputfelder belegt sind, dann den Bestand anschauen
						if (istAnzahlVorhanden && istNameVorhanden) {
							createAnbieterstand(oEntry, oModel);
							resetInput(oCombo, oInput, oRouter);
						} else {
							MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: "",
								actions: [sap.m.MessageBox.Action.OK]
							});
							resetInputNoRout(oCombo, oInput);
						}
					} else {
						MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "",
							actions: [sap.m.MessageBox.Action.OK]
						});
						resetInputNoRout(oCombo, oInput);
					} //wenn der Name nicht enthalten ist, dann geb eine Nachricht aus und resete die Inputfelder
				},
				error: function (oError) {}
			});
		},
		/**
		 *@memberOf namespace.Supermarkt.controller.BestellungSicht
		 */
		erstelleStandNeu: function (oEvent) {

			function updateProduktliste(oEntry1, oModel) {

				oModel.update("/Produktliste(AnbieterID="+oEntry1.AnbieterID+",Produktnummer="+oEntry1.Produktnummer+")", oEntry1, {
					merge: true,
					success: function (oData, oResult) {

					}

				});
			}

			function createLager(oEntry, oModel, Produktnummer) {

				oModel.read("/Lager", {
					sorters: [
						new Sorter("ProduktID", /*descending*/ true) // "Sorter" required from "sap/ui/model/Sorter"
					],
					urlParameters: {
						"$select": "ProduktID",
						"$top": 1,
					},
					success: function (data) {
						var highestProdId = data.results[0].ProduktID;
						oEntry.ProduktID = highestProdId + 1;

						oModel.create("/Lager", oEntry, {});

						var oEntry1 = {};

						oEntry1.AnbieterID = oEntry.AnbieterID;
						oEntry1.Produktnummer = Produktnummer;
						oEntry1.ProduktID = oEntry.ProduktID;

						//oEntry.Produktnummer = Produktnummer;
						updateProduktliste(oEntry1,oModel);
						// ...
					},
					error: function (oError) {
						MessageBox.show("kein sortieren", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "",
							actions: [sap.m.MessageBox.Action.OK]
						});

					}
				});

			}
			// Funktionen zum Leeren der Inputfelder mit/ohne zur Navigation zurück zur Übersicht.
			function resetInput(oCombo, oInput1, oInput2, oRouter) {
				oCombo.setSelectedKey("");
				oInput1.setValue("");
				oInput2.setValue("");
				oRouter.navTo("Uebersicht");
			}

			function resetInputNoRout(oCombo, oInput1, oInput2) {
				oCombo.setSelectedKey("");
				oInput1.setValue("");
				oInput2.setValue("");
			}

			//Hole Model und Router von der View
			var oModel = this.getView().getModel();
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//Hole die Combobox, sowie der eingegebene Wert
			var oCombo = this.getView().byId("combo2");
			var PrName = oCombo.getValue();
			//hole die Inputbox sowie dessen Wert, konvertiere diesen Wert zu einem Int
			var oInput1 = this.getView().byId("input1");
			var Anzahl = oInput1.getValue();
			var IntAnzahl = parseInt(Anzahl);

			var oInput2 = this.getView().byId("input2");
			var Anzahl2 = oInput2.getValue();
			var IntAnzahl2 = parseInt(Anzahl2);
			//boolesche Variablen zum Überprüfen, dass die Inputfelder belegt wurden
			var istNameVorhanden = false;
			var istAnzahlVorhanden = false;
			var istSchwelleVorhanden = false;

			//Deklarierung von oEntry, später genutzt zum Updaten der Datenbank
			var oEntry = {};
			//erstelle einen Filter, um den gegebenen Datensatz mit  dem eingegebenen Produktnamen zu vergleichen
			var filter = new sap.ui.model.Filter("ProName", sap.ui.model.FilterOperator.EQ, "" + PrName + "");
			//prüft, ob Zahl eingegeben wurde
			if (Anzahl.length !== 0) {
				istAnzahlVorhanden = true;
			}
			if (Anzahl2.length !== 0) {
				istSchwelleVorhanden = true;
			}

			//Lese aus der Datenbank, ob ein Datensatz mit dem eingegebenen namen existiert
			oModel.read("/Produktliste", {
				filters: [filter],
				success: function (oData, oResult) {
					//wenn dieser Satz existiert, und nur dieser, dann bereite das Updaten vor
					if (oData.results.length === 1) {
						istNameVorhanden = true;
						//oEntry mit gegebenen Satz belegen

						oEntry.PrName = PrName;
						oEntry.Bestand = IntAnzahl;
						oEntry.Schwellenwert = IntAnzahl2;
						oEntry.Preis = oData.results[0].Preis;
						oEntry.AnbieterID = oData.results[0].AnbieterID;
						oEntry.AnbName = oData.results[0].AnbName;
						oEntry.Adresse = oData.results[0].Adresse;
						oEntry.Ort = oData.results[0].Ort;
						var Produktnummer = oData.results[0].Produktnummer;
						//wenn alle Inputfelder belegt sind, dann den Bestand anschauen
						if (istAnzahlVorhanden && istNameVorhanden && istSchwelleVorhanden) {
							createLager(oEntry, oModel, Produktnummer);

							resetInput(oCombo, oInput1, oInput2, oRouter);
						} else {
							MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
								icon: sap.m.MessageBox.Icon.INFORMATION,
								title: "",
								actions: [sap.m.MessageBox.Action.OK]
							});
							resetInputNoRout(oCombo, oInput1, oInput2);
						}
					} else {
						MessageBox.show("Die eingegebenen Felder sind nicht korrekt ausgef\xFCllt. Bitte erneut eingeben!", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "",
							actions: [sap.m.MessageBox.Action.OK]
						});
						resetInputNoRout(oCombo, oInput1, oInput2);
					} //wenn der Name nicht enthalten ist, dann geb eine Nachricht aus und resete die Inputfelder
				},
				error: function (oError) {}
			});
		},
		/**
		 *@memberOf namespace.Supermarkt.controller.BestellungSicht
		 */

	});
});